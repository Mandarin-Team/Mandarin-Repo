package ru.mandarin.discordipc;

import java.io.InputStream;

public record UserAvatar(InputStream inputStream, AvatarType avatarType) {
}
