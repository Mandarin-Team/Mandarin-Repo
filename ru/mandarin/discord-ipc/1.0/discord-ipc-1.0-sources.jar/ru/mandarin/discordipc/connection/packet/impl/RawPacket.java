package ru.mandarin.discordipc.connection.packet.impl;

import ru.mandarin.discordipc.connection.packet.S2CPacket;
import ru.mandarin.discordipc.connection.packet.opcode.Opcode;

public class RawPacket implements S2CPacket {

    @Override
    public Opcode getOpcode() {
        return null;
    }
}
