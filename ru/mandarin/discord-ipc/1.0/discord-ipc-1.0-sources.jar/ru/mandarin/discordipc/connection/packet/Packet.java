package ru.mandarin.discordipc.connection.packet;

import ru.mandarin.discordipc.connection.packet.opcode.Opcode;

public interface Packet {

    Opcode getOpcode();
}
