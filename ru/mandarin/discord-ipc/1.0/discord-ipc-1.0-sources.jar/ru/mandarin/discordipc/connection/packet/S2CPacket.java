package ru.mandarin.discordipc.connection.packet;

public interface S2CPacket extends Packet {
}
