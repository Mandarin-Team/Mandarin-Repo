package ru.mandarin.discordipc;

public enum AvatarType {
    Image,
    Gif
}
