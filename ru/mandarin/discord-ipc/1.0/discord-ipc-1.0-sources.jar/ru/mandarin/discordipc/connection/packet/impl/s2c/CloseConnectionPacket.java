package ru.mandarin.discordipc.connection.packet.impl.s2c;

import ru.mandarin.discordipc.connection.packet.S2CPacket;
import ru.mandarin.discordipc.connection.packet.opcode.Opcode;

public record CloseConnectionPacket(int code, String message) implements S2CPacket {

    @Override
    public Opcode getOpcode() {
        return Opcode.Close;
    }
}
