package ru.mandarin.discordipc.connection.packet;

import com.google.gson.JsonObject;

public interface C2SPacket extends Packet {

    JsonObject toJson();
}
